from django.db import models

class Categoria(models.Model):
    nombre = models.CharField(max_length=100)

class Marca(models.Model):
    nombre = models.CharField(max_length=100)

class Caracteristica(models.Model):
    nombre = models.CharField(max_length=100)

class Productos(models.Model):
    codigo = models.CharField(max_length=20)
    nombre = models.CharField(max_length=100)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    marca = models.ForeignKey(Marca, on_delete=models.CASCADE)
    caracteristicas = models.ManyToManyField(Caracteristica)
    
class Productos(models.Model):
    codigo = models.CharField(max_length=20)
    nombre = models.CharField(max_length=100)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    marca = models.ForeignKey(Marca, on_delete=models.CASCADE)
    caracteristicas = models.ManyToManyField(Caracteristica)
    descripcion = models.TextField(default="", blank=True)  # Nuevo campo agregado

