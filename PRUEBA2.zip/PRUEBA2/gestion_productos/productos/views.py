# productos/views.py
from django.shortcuts import render, redirect
from .models import Producto, Categoria, Marca
from django.http import HttpResponse

def index(request):
    productos = Producto.objects.all()
    return render(request, 'index.html', {'productos': productos})

def register(request):
    if request.method == 'POST':
        codigo = request.POST['codigo']
        nombre = request.POST['nombre']
        precio = request.POST['precio']
        categoria_id = request.POST['categoria']
        marca_id = request.POST['marca']
        categoria = Categoria.objects.get(id=categoria_id)
        marca = Marca.objects.get(id=marca_id)

        producto = Producto(codigo=codigo, nombre=nombre, precio=precio, categoria=categoria, marca=marca)
        producto.save()
        return render(request, 'result.html', {'producto': producto})
    
    categorias = Categoria.objects.all()
    marcas = Marca.objects.all()
    return render(request, 'register.html', {'categorias': categorias, 'marcas': marcas})

def result(request):
    return render(request, 'result.html')
